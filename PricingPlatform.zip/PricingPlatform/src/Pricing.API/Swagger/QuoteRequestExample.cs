using Swashbuckle.AspNetCore.Filters;
using Pricing.Domain.Models;

public class QuoteRequestExample : IExamplesProvider<QuoteRequest>
{
    public QuoteRequest GetExamples()
    {
        return new QuoteRequest
        {
            Weight = 5,
            Destination = "REMOTE",
            RequestTime = DateTime.Parse("2026-01-01T13:00:00")
        };
    }
}