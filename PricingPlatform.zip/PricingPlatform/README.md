1. วิธีรันโปรเจคโดยใช้ Docker

1.1 ติดตั้ง Docker
ดาวน์โหลดและติดตั้ง Docker Desktop

1.2 รันโปรเจค
เปิด Terminal แล้วรันคำสั่ง:
docker-compose up --build

1.3 เข้าใช้งานระบบ
เปิด Browser:
http://localhost:5000/swagger

2. วิธีรันแบบ Developer (.NET)
2.1 ติดตั้ง .NET 8 SDK

2.2 รันโปรเจค
cd src/Pricing.API
dotnet restore
dotnet run

3. เข้าใช้งาน
http://localhost:5000/swagger

ตัวอย่างการใช้งาน API
🔹 Health Check
GET /health
🔹 คำนวณราคาทันที
POST /quotes/price
Body:
{
  "weight": 5,
  "destination": "REMOTE",
  "requestTime": "2026-01-01T13:00:00"
}
🔹 คำนวณแบบหลายรายการ (Bulk)
POST /quotes/bulk
Body:
[
  {
    "weight": 5,
    "destination": "REMOTE",
    "requestTime": "2026-01-01T13:00:00"
  }
]
Response:
{
  "job_id": "xxxx"
}
🔹 ตรวจสอบสถานะงาน
GET /jobs/{job_id}